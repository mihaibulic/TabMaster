TabMaster is a Chrome Extension. Below is the description in the chrome web store:

   Like pinned tabs, but don't like them disappearing on you?  With TabMaster, you can enter in several web sites which you'd like to be pinned to every browser window you have (green arrows in picture).  Just visit this extensions options menu (blue arrow in picture). 

Like being able to switch between tabs using ctrl+# or alt+#, but don't like having to count to see if gmail.com is the 5th or 6th tab?  With TabMaster, just hold ctrl+` or alt+` (the key to the left of the 1 button) and your tabs will display their tab number (red arrows in picture). 

